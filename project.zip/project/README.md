# FIT2101 Project

 - <b>Group Number</b>: 2
 - <b>Group Name</b>: \<NAME NOT FOUND\>

```diff
+ PROJECT IN PROGRESS
```

This repository will serve as the main starting-off point for our team's Agile project. It will contain all the necessary code and documentation for the project.

Listed below are all the team members/contributors of the project:

<table>

 <tr>
     <td><h3>Contributor Name</h3></td>
     <td><h3>Role</h3></td>
 </tr>
 
 <tr>
     <td>Anas Qumhiyeh</td>
     <td>Scrum Master</td>
 </tr>
 
 <tr>
     <td>Lahiru Weliwitiya</td>
     <td>UI/UX/Backend Developer</td>
 </tr>
 
 <tr>
     <td>Chean Hao</td>
     <td>Product Owner</td>
 </tr>
 
 <tr>
     <td>Zhen Ni</td>
     <td>Seceretary</td>
 </tr>
 
 <tr>
     <td>Yan Zimeng (Gina)</td>
     <td>Backend Developer</td>
 </tr>

</table>

<br></br>

(TO BE UPDATED AS THE PROJECT PROGRESSES)
