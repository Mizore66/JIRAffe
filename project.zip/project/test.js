// on click event of button with id "btn"
$(document).ready(function () {

  console.log("wassup my gigga nigga");

  $("#btn").on("click", function () {
    console.log("Get a job lil nigga");
  });
  
});
